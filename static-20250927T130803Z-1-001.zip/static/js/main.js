
document.getElementById('capture').addEventListener('click', async () => {
    const canvas = document.getElementById('outputCanvas');
    const video = document.getElementById('videoFeed');


    canvas.getContext('2d').drawImage(video, 0, 0, 640, 480);

    // Converting to JPEG
    canvas.toBlob(async (blob) => {
        try {
            const formData = new FormData();
            formData.append('image', blob, 'frame.jpg');

            const response = await fetch('/predict', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if(result.error) {
                console.error('Error:', result.error);
                return;
            }


            document.getElementById('emotionResult').textContent = result.emotion;
            document.getElementById('confidenceResult').textContent =
                `Confidence: ${result.confidence}`;

        } catch (error) {
            console.error('Detection failed:', error);
        }
    }, 'image/jpeg', 0.9);
});