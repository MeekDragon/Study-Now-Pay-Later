let mediaStream = null;
let analysisInterval = null;


async function processFrame() {
    try {
        const video = document.getElementById('videoFeed');
        if (!video || video.readyState < 2) {
            throw new Error('Video feed not ready');
        }

        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');


        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);


        const blob = await new Promise(resolve =>
            canvas.toBlob(resolve, 'image/jpeg', 0.8)
        );


        const formData = new FormData();
        formData.append('frame', blob, 'frame.jpg');

        const response = await fetch('/analyze', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) throw new Error('Analysis failed');
        const result = await response.json();

        updateUI(result);

    } catch (error) {
        console.error('Frame processing error:', error);
        showError(`Analysis error: ${error.message}`);
    }
}


function updateUI(result) {

    const emotionElement = document.getElementById('currentEmotion');
    if (emotionElement) {
        emotionElement.textContent = result.dominant_emotion || 'Neutral';
    }


    const stressElement = document.getElementById('stressLevel');
    if (stressElement) {
        stressElement.textContent = `Stress: ${result.stress?.toFixed(1) || 0}%`;
    }
}


function showError(message) {
    const errorElement = document.getElementById('errorMessage');
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
        setTimeout(() => {
            errorElement.style.display = 'none';
        }, 5000);
    }
}


async function startWebcam() {
    try {
        mediaStream = await navigator.mediaDevices.getUserMedia({
            video: { width: 640, height: 480 }
        });

        const videoElement = document.getElementById('videoFeed');
        if (videoElement) {
            videoElement.srcObject = mediaStream;
        }


        const captureButton = document.getElementById('capture');
        if (captureButton) {
            captureButton.disabled = false;
        }


        analysisInterval = setInterval(processFrame, 2000);

    } catch (error) {
        showError(`Camera error: ${error.message}`);
        if (mediaStream) {
            mediaStream.getTracks().forEach(track => track.stop());
        }
    }
}


window.addEventListener('beforeunload', () => {
    if (mediaStream) {
        mediaStream.getTracks().forEach(track => track.stop());
    }
    clearInterval(analysisInterval);
});


if (document.getElementById('videoFeed')) {
    document.addEventListener('DOMContentLoaded', () => {
        const startButton = document.getElementById('startCamera');
        if (startButton) {
            startButton.addEventListener('click', startWebcam);
        }
    });
}