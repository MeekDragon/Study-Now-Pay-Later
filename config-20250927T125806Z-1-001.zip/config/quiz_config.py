
QUESTION_BANK = {
    "Data Structures & Algorithm": {
        "title": "Data Structures & Algorithms",
        "questions": {
            "q1": {
                "text": "What is the time complexity of binary search algorithm?",
                "options": { "A": "O(1)", "B": "O(n)", "C": "O(log n)" },
                "correct": "C"
            },
            "q2": {
                "text": "Which data structure uses FIFO (First-In-First-Out) principle?",
                "options": { "A": "Stack", "B": "Queue", "C": "Tree" },
                "correct": "B"
            },
            "q3": {
                "text": "Which of these sorting algorithms has a worst-case time complexity of O(n^2), although it's often efficient in practice?",
                "options": { "A": "Merge Sort", "B": "Quick Sort", "C": "Heap Sort" },
                "correct": "B"
            },
            "q4": {
                "text": "Which layer in the OSI model is responsible for logical addressing?",
                "options": { "A": "Physical Layer", "B": "Network Layer", "C": "Transport Layer" },
                "correct": "B"
            }
        }
    },
    "oop": {
        "title": "Object-Oriented Programming",
        "questions": {
            "q1": {
                "text": "In OOP, what is the process of hiding implementation details called?",
                "options": { "A": "Inheritance", "B": "Polymorphism", "C": "Encapsulation" },
                "correct": "C"
            },

            "q2": {
                "text": "What OOP concept allows a class to inherit properties and methods from another class?",
                "options": { "A": "Encapsulation", "B": "Inheritance", "C": "Abstraction" },
                "correct": "B"
            },
            "q3": {
                "text": "The ability of an object or method to take on many forms is known as:",
                "options": { "A": "Polymorphism", "B": "Overloading", "C": "Encapsulation" },
                "correct": "A"
            },
            "q4": {
                "text": "In OOP, what serves as a blueprint or template for creating objects?",
                "options": { "A": "Method", "B": "Instance", "C": "Class" },
                "correct": "C"
            }

        }
    },
    #  COMPUTER NETWORKS TOPIC ---
    "CN": {
        "title": "Computer Networks",
        "questions": {
            "q1": {
                "text": "In networking, what does 'IP' stand for?",
                "options": { "A": "Internal Process", "B": "Internet Protocol", "C": "Information Packet" },
                "correct": "B"
            },
            "q2": {
                "text": "Which layer of the TCP/IP model provides reliable, end-to-end data transmission?",
                "options": { "A": "Network Layer", "B": "Data Link Layer", "C": "Transport Layer" },
                "correct": "C"
            },
            "q3": {
                "text": "What type of address uniquely identifies a network interface card (NIC) on a local network segment?",
                "options": { "A": "IP Address", "B": "Port Number", "C": "MAC Address" },
                "correct": "C"
            },
            "q4": {
                "text": "What is the primary function of the Domain Name System (DNS) in networking?",
                "options": { "A": "Assigning IP addresses (DHCP)", "B": "Translating domain names to IP addresses", "C": "Encrypting network traffic (SSL/TLS)" },
                "correct": "B"
            }
        }
    }

}